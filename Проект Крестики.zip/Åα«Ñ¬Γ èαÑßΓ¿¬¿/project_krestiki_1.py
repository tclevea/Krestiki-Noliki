import pygame
import random
import sys
import os

# Инициализация Pygame
pygame.init()

# Определяем размеры экрана и цвета
WIDTH, HEIGHT = 600, 600
MAIN_BG_COLOR = (102, 14, 96)  # Главный экран: #660e60
LINE_COLOR = (172, 111, 130)  # Линии: #ac6f82
BOARD_COLOR = (102, 14, 96)  # Игровое поле: #660e60
TEXT_COLOR = (172, 111, 130)  # Надписи: #ac6f82
BUTTON_COLOR = (172, 111, 130)  # Кнопки: #ac6f82
WHITE = (255, 255, 255)
X_COLOR = (172, 111, 130)  # Цвет крестиков: #ac6f82
O_COLOR = (172, 111, 130)  # Цвет ноликов: #ac6f82
BUTTON_TEXT_COLOR = (100, 30, 70)  # Цвет текста на кнопках (темнее): #642346
DRAW_TEXT_COLOR = (172, 111, 130)  # Цвет текста ничьей: #ac6f82

# Настройки для окна
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Крестики-нолики')

# Шрифты
font = pygame.font.Font(None, 60)
button_font = pygame.font.Font(None, 40)

# Глобальные переменные
current_player = 'O'  # Первый ход всегда за "O"
board = [' '] * 9  # Игровое поле (список из 9 элементов)
game_over = False
winner = None
mode = 0


def draw_board():
    """Отрисовывает игровое поле"""
    screen.fill(BOARD_COLOR)

    # Рисуем сетку
    pygame.draw.line(screen, LINE_COLOR, (200, 0), (200, HEIGHT), 5)
    pygame.draw.line(screen, LINE_COLOR, (400, 0), (400, HEIGHT), 5)
    pygame.draw.line(screen, LINE_COLOR, (0, 200), (WIDTH, 200), 5)
    pygame.draw.line(screen, LINE_COLOR, (0, 400), (WIDTH, 400), 5)

    # Рисуем фигуры на поле
    for i in range(9):
        x = (i % 3) * 200 + 100
        y = (i // 3) * 200 + 100
        if board[i] == 'X':
            pygame.draw.line(screen, X_COLOR, (x - 50, y - 50), (x + 50, y + 50), 15)
            pygame.draw.line(screen, X_COLOR, (x + 50, y - 50), (x - 50, y + 50), 15)
        elif board[i] == 'O':
            pygame.draw.circle(screen, O_COLOR, (x, y), 50, 15)

    pygame.display.update()


def check_winner():
    """Проверка на победителя"""
    global winner
    # Все возможные комбинации для победы
    win_combinations = [(0, 1, 2), (3, 4, 5), (6, 7, 8),  # Горизонтальные линии
                        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Вертикальные линии
                        (0, 4, 8), (2, 4, 6)]  # Диагонали
    for combo in win_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] != ' ':
            winner = board[combo[0]]
            return True
    return False


def check_draw():
    """Проверка на ничью"""
    if ' ' not in board:  # Если нет пустых клеток
        return True
    return False


def computer_move():
    """Ход компьютера (выбор случайной пустой клетки)"""
    available_moves = [i for i in range(9) if board[i] == ' ']
    move = random.choice(available_moves)
    board[move] = 'X'
    return move


def reset_game():
    """Сброс игры"""
    global board, current_player, game_over, winner
    board = [' '] * 9
    current_player = 'O'
    game_over = False
    winner = None


def draw_main_menu():
    """Отображение главного меню"""
    screen.fill(MAIN_BG_COLOR)
    play_computer_button = pygame.Rect(150, 200, 300, 50)
    play_friend_button = pygame.Rect(150, 300, 300, 50)

    pygame.draw.rect(screen, BUTTON_COLOR, play_computer_button)
    pygame.draw.rect(screen, BUTTON_COLOR, play_friend_button)

    text1 = button_font.render("Игра с компьютером", True, BUTTON_TEXT_COLOR)
    text2 = button_font.render("Игра с другом", True, BUTTON_TEXT_COLOR)
    screen.blit(text1, (play_computer_button.x + 10, play_computer_button.y + 10))
    screen.blit(text2, (play_friend_button.x + (play_friend_button.width - text2.get_width()) // 2, play_friend_button.y + 10))

    pygame.display.update()

    return play_computer_button, play_friend_button


def draw_game_over(winner):
    """Отображение конца игры"""
    global mode
    screen.fill(MAIN_BG_COLOR)
    text = ''
    if mode == 1: # Проверка на то, какой режим (игра с компьютером)
        if winner == 'O':
            text = font.render("Вы победили!", True, O_COLOR)
        elif winner == 'X':
            text = font.render("Победил компьютер!", True, X_COLOR)
        else:
            text = font.render("Ничья!", True, DRAW_TEXT_COLOR)  # Текст ничьей с новым цветом

    if mode == 2: # Проверка на то, какой режим (игра с другом)
        if winner == 'O':
            text = font.render("Победили нолики!", True, O_COLOR)
        elif winner == 'X':
            text = font.render("Победили крестики!", True, X_COLOR)
        else:
            text = font.render("Ничья!", True, DRAW_TEXT_COLOR)

    # Сдвигаем текст влево, чтобы он был по центру
    text_x = (WIDTH - text.get_width()) // 2
    screen.blit(text, (text_x, HEIGHT // 3))

    play_again_button = pygame.Rect(150, 400, 300, 50)
    pygame.draw.rect(screen, BUTTON_COLOR, play_again_button)
    play_again_text = button_font.render("Вернуться в меню", True, BUTTON_TEXT_COLOR)

    # Центрируем текст на кнопке
    play_again_text_x = (play_again_button.width - play_again_text.get_width()) // 2 + play_again_button.x
    play_again_text_y = (play_again_button.height - play_again_text.get_height()) // 2 + play_again_button.y
    screen.blit(play_again_text, (play_again_text_x, play_again_text_y))

    pygame.display.update()

    return play_again_button


def load_image(name, colorkey=None): # Загружаем и конвертируем изображение
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image


def terminate():
    """Аварийное завершение"""
    pygame.quit()
    sys.exit()


def start_screen():
    """Заставка игры"""
    rules_text = ["Правила игры:",
                  "Игроки по очереди ставят на свободные клетки поля.",
                  "Первый, выстроивший в ряд 3 своих фигуры выигрывает.",
                  "Если игроки заполнили все 9 ячеек и оказалось,",
                  "что нет трёх одинаковых знаков,",
                  "партия считается закончившейся вничью.",
                  "Первый ход делют нолики."]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 25) # Шрифт для основного текста
    font_1 = pygame.font.Font(None, 50) # Шрифт для заголовка
    text_coord = 170

    # Заголовок
    text_1 = font_1.render("Крестики-Нолики", True, pygame.Color('white'))
    screen.blit(text_1, (150, 50, 100, 50))
    # Надпись внизу заставки
    text_2 = font.render("Для продолжения нажмите на экран", True, pygame.Color('white'))
    screen.blit(text_2, (125, 550, 100, 50))

    for line in rules_text: # Отрисовка правил игры
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True: # Для прололжения игры
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


def main():
    """Основной цикл игры"""
    global current_player, game_over, winner, mode
    clock = pygame.time.Clock()
    start_screen()

    in_main_menu = True
    while True:
        screen.fill(WHITE)  # Это обеспечит чистоту экрана перед рендерингом

        if in_main_menu:
            play_computer_button, play_friend_button = draw_main_menu()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if play_computer_button.collidepoint(event.pos):
                        in_main_menu = False
                        mode = 1
                        reset_game()
                        # Стартуем игру с компьютером
                    elif play_friend_button.collidepoint(event.pos):
                        # Включаем режим игры с другом
                        in_main_menu = False
                        mode = 2
                        reset_game()
        else:
            # Если игра не завершена, рисуем поле
            if not game_over:
                draw_board()

            if game_over:
                play_again_button = draw_game_over(winner)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if play_again_button.collidepoint(event.pos):
                            in_main_menu = True
                            reset_game()
            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button == 1:  # Проверка на клик мышью
                            pos = event.pos
                            row, col = pos[1] // 200, pos[0] // 200  # Находим клетку
                            index = row * 3 + col
                            if board[index] == ' ':  # Если клетка пустая
                                board[index] = current_player
                                if check_winner():  # Проверка на победу
                                    game_over = True
                                elif check_draw():  # Проверка на ничью
                                    game_over = True
                                else:
                                    current_player = 'X' if current_player == 'O' else 'O'

                                # Если сейчас ход компьютера (игра с компьютером), то делаем ход компьютера
                                if current_player == 'X' and not game_over and mode == 1:
                                    move = computer_move()  # Компьютер делает ход
                                    if check_winner():  # Проверка на победу после хода компьютера
                                        game_over = True
                                    elif check_draw():  # Проверка на ничью после хода компьютера
                                        game_over = True
                                    else:
                                        current_player = 'O'  # Меняем ход на игрока
                                draw_board()  # Перерисовываем поле после каждого хода

            # После окончания игры мы не обновляем экран, пока не нажмут кнопку для перезапуска
            pygame.display.update()  # Обновляем экран только после рисования конца игры
            clock.tick(30)


if __name__ == "__main__":
    main()
